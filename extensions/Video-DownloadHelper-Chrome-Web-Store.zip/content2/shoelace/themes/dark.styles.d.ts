declare const _default: import("lit").CSSResult;
export default _default;
